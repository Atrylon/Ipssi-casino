# Ipssi-casino

Petit programme de casino où le but est de deviner le nombre enregistré par le casino pour tenter d'augmenter son argent.

Chaque niveau est enregistré dans un fichier json pour pouvoir en fait des statistiques
